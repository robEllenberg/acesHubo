#!/bin/sh

# ************************************************************************
# *     install script for 3DxWare for Unix release version 1.5.2
# *                         (C) 3Dconnexion 2009
# *                         www.3dconnexion.com
# ************************************************************************

PWD="/bin/pwd"
UNAME="/bin/uname"
UNAME_M="/bin/uname -m"
UNAME_P="/bin/uname -p"
UNAME_R="/bin/uname -r"
MACHINE=`$UNAME_M`
WHOAMI="/usr/bin/whoami"
USER=`$WHOAMI`
TMP="/tmp"

if [ -x "/sbin/init" ]
then
	INIT_Q="/sbin/init q"
elif [ -x "/usr/sbin/init" ]
then
	INIT_Q="/usr/sbin/init q"
else [ -x "/etc/init" ]
	INIT_Q="/etc/init q"
fi

if [ -x "/bin/echo" ]
then
	ECHO="/bin/echo"
else [ -x "/usr/bin/echo" ]
	ECHO="/usr/bin/echo"
fi

if [ -r "INSTALL-3DXUNIX.SH;1" ]
then
	HPUX_TGZ=3DXWARE-HPUX-V1-5-2.TGZ\;1
	HPUX_TAR_GZ1=3DXWARE-HPUX-V1-5-2.TAR.GZ\;1
	HPUX_TAR_GZ=3dxware-hpux-v1-5-2.tar.gz
	HPUX_TAR=3dxware-hpux-v1-5-2.tar
elif [ -r "INSTALL_3DXUNIX.SH;1" ]
then
	HPUX_TGZ=3DXWARE_HPUX_V1_5_2.TGZ\;1
	HPUX_TAR_GZ1=3DXWARE_HPUX_V1_5_2.TAR.GZ\;1
	HPUX_TAR_GZ=3dxware_hpux_v1_5_2.tar.gz
	HPUX_TAR=3dxware_hpux_v1_5_2.tar
elif [ -r "install_3dxunix.sh" ]
then
	HPUX_TGZ=3dxware_hpux_v1_5_2.tgz
	HPUX_TAR_GZ1=3dxware_hpux_v1_5_2.tar.gz
	HPUX_TAR_GZ=3dxware_hpux_v1_5_2.tar.gz
	HPUX_TAR=3dxware_hpux_v1_5_2.tar
elif [ -r "install_3dxunix.sh;1" ]
then
	HPUX_TGZ=3dxware_hpux_v1_5_2.tgz\;1
	HPUX_TAR_GZ1=3dxware_hpux_v1_5_2.tar.gz\;1
	HPUX_TAR_GZ=3dxware_hpux_v1_5_2.tar.gz
	HPUX_TAR=3dxware_hpux_v1_5_2.tar
elif [ -r "install-3dxunix.sh;1" ]
then
	HPUX_TGZ=3dxware-hpux-v1-5-2.tgz\;1
	HPUX_TAR_GZ1=3dxware-hpux-v1-5-2.tar.gz\;1
	HPUX_TAR_GZ=3dxware-hpux-v1-5-2.tar.gz
	HPUX_TAR=3dxware-hpux-v1-5-2.tar
else [ -r "install-3dxunix.sh" ]
	HPUX_TGZ=3dxware-hpux-v1-5-2.tgz
	HPUX_TAR_GZ1=3dxware-hpux-v1-5-2.tar.gz
	HPUX_TAR_GZ=3dxware-hpux-v1-5-2.tar.gz
	HPUX_TAR=3dxware-hpux-v1-5-2.tar
fi


AIX_TAR_GZ=3dxware-aix5-v1-5-2.tar.gz
AIX_TAR=3dxware-aix5-v1-5-2.tar

if [ `$UNAME_M` = "x86_64" ]
then
	LINUX_TAR_GZ=3dxware-linux-v1-5-2.x86_64.tar.gz
 	LINUX_TAR=3dxware-linux-v1-5-2.x86_64.tar
else
	LINUX_TAR_GZ=3dxware-linux-v1-5-2.i386.tar.gz
	LINUX_TAR=3dxware-linux-v1-5-2.i386.tar
fi


if [ `$UNAME` = "SunOS" ]
then
	if [ `$UNAME_P` = "sparc" ]
	then
		SOLARIS_TAR_GZ=3dxware-solaris-v1-5-2-sparc.tar.gz
 		SOLARIS_TAR=3dxware-solaris-v1-5-2-sparc.tar
	else
		SOLARIS_TAR_GZ=3dxware-solaris-v1-5-2-x86.tar.gz
		SOLARIS_TAR=3dxware-solaris-v1-5-2-x86.tar
	fi
fi

# ************************************************************************
# *     CLEAR
# ************************************************************************
CLEAR ()
{
	$ECHO ""
	$ECHO ""
	$ECHO ""
	$ECHO ""
	$ECHO ""
	$ECHO ""
	$ECHO ""
	$ECHO ""
	$ECHO ""
}
# ************************************************************************
# *     FatalError
# ************************************************************************
FatalError ()
{
	$ECHO ""
	$ECHO "Installation failed!"
	$ECHO ""
	exit 1
}
# ************************************************************************
# *     NormalError
# ************************************************************************
NormalError ()
{
	$ECHO ""
	$ECHO "Installation aborted."
	$ECHO ""
	exit 2
}

# ************************************************************************
# *      ShutdownXdriver
# ************************************************************************
ShutdownExistingDriver()
{
	$ECHO "Uninstalling a running driver. Please wait ..."

	cp /etc/inittab /tmp/inittab.org
	if [ "$1" = "aix" ]
	then
		sed -e 's/xm:234/:xm:234/g' /etc/inittab > /tmp/inittab.new
	else
		sed -e 's/xm:234/#xm:234/g' /etc/inittab > /tmp/inittab.new
	fi

	grep -v "3d:234" /tmp/inittab.new > /etc/inittab

	`$INIT_Q`
	/etc/3DxWare/daemon/3dxsrv -exit > /dev/null 2>&1
	sleep 1
	$ECHO "Done."
}


# ************************************************************************
# *      Install3DxWare
# ************************************************************************
Install3DxWare ()
{
	$ECHO "Installing files for 3DxWare for Unix / $1......"
	$ECHO ""

	ShutdownExistingDriver $1

	if [ "$1" = "aix" ]
	then
		cp $AIX_TAR_GZ $TMP
		cd $TMP
		gzip -d $TMP/$AIX_TAR_GZ
		tar -oxf $TMP/$AIX_TAR 
	fi

	if [ "$1" = "hpux" ]
	then
		if [ -r $HPUX_TGZ ]
		then
			cp $HPUX_TGZ $TMP/$HPUX_TAR_GZ
		elif [ -r $HPUX_TAR_GZ1 ]
		then
			cp $HPUX_TAR_GZ1 $TMP/$HPUX_TAR_GZ
		else
			cp $HPUX_TAR_GZ $TMP/$HPUX_TAR_GZ
		fi
		cd $TMP
		gzip -d $TMP/$HPUX_TAR_GZ
		tar -oxf $TMP/$HPUX_TAR
	fi

	if [ "$1" = "solaris" ]
	then
		if [ `$UNAME_R` = "5.10" ]
		then
			/usr/sbin/rem_drv ugen
			/usr/sbin/add_drv -i '"usb46d,c603" "usb46d,c621" "usb46d,c623" "usb46d,c625" "usb46d,c626" "usb46d,c627" "usb46d,c628" "usb46d,c629"' ugen
		else
			/usr/sbin/rem_drv usba10_ugen
			/usr/sbin/add_drv -i '"usb46d,c603" "usb46d,c621" "usb46d,c623" "usb46d,c625" "usb46d,c626" "usb46d,c627" "usb46d,c628" "usb46d,c629"' usba10_ugen
		fi
		cp $SOLARIS_TAR_GZ $TMP
		cd $TMP
		gzip -d $TMP/$SOLARIS_TAR_GZ
		tar -oxf $TMP/$SOLARIS_TAR
	fi

	if [ "$1" = "linux" ]
	then
		cp $LINUX_TAR_GZ $TMP
		cd $TMP
		tar -oxzf $TMP/$LINUX_TAR_GZ
	fi

	cp -R $TMP/etc/* /etc
	rm -rf $TMP/etc $TMP/InstallationInstructions_*_1-5-2.txt

	# convert old configs to new V5.3 config format
	$ECHO ""
	$ECHO ""
	$ECHO "Converting default configs V5.x to V5.3."
	$ECHO "(User configs will be converted when used)"
	$ECHO "Please wait a moment..."
	/etc/3DxWare/daemon/3dxsrv -convertConfigs

	# the end
	$ECHO ""
	$ECHO "Done."
}

# ************************************************************************
# *      DisplayUsage
# ************************************************************************
DisplayUsage ()
{
  $ECHO ""
  $ECHO ""
  $ECHO "****************************************************************"
  $ECHO ""
  $ECHO "    For testing purposes you can find the demos"
  $ECHO "                      xcube and xvalues at $TMP"
  $ECHO ""
  $ECHO "****************************************************************"
  $ECHO ""
  $ECHO ""
}


# ************************************************************************
# *      DisplayMenu
# ************************************************************************
DisplayMenu ()
{
  $ECHO ""
  $ECHO " Choose one of the following platforms:"
  $ECHO ""
  $ECHO "  1.  HP-UX"
  $ECHO "  2.  Solaris"
  $ECHO "  3.  AIX 5"
  $ECHO "  4.  Linux"
  $ECHO "  5.  Exit"
  $ECHO ""
  $ECHO "Please enter your choice (1-5)[$DEFAULT_CHOICE]: "
}

# ************************************************************************
# *      DisplayPortChoice1
# ************************************************************************
DisplayPortChoice1 ()
{
	$ECHO ""
	$ECHO "To which port is the device attached?"
}

# ************************************************************************
# *      DisplayPortChoice2
# ************************************************************************
DisplayPortChoice2 ()
{
	$ECHO " 3. Exit installation"
	$ECHO ""
 	$ECHO "Please enter your choice (1 - 3): [1]"
	$ECHO ""
	read PORT
	$ECHO ""
	if [ -z "$PORT" ]
	then
		PORT=1
	fi
}

# ************************************************************************
# *      DisplayStartinittabInstallation
# ************************************************************************
DisplayStartInittabInstallation ()
{
	$ECHO "Installing start from /etc/inittab ..."
}

# ************************************************************************
# *      DisplayEndinittabInstallation
# ************************************************************************
DisplayEndInittabInstallation ()
{
	DEVICE=3
	PORT=3
	`$INIT_Q`
	$ECHO ""
	$ECHO ""
	$ECHO "Done."
	$ECHO ""
}

# ************************************************************************
# *      InstallSerialToInittab
# ************************************************************************
InstallSerialToInittab ()
{
	until [ "$PORT" = "3" ]
	do
		DisplayPortChoice1
		$ECHO " 1. $1"
		$ECHO " 2. $2"
		DisplayPortChoice2
		if [ "$PORT" = "1" ]
		then
			DisplayStartInittabInstallation
			if [ "$PLATFORM" = "4" ]
			then
			$ECHO "3d:2345:respawn:/etc/3DxWare/daemon/3dxsrv -d $1 </dev/null >/dev/null 2>&1" >> /etc/inittab
			else
			$ECHO "3d:234:respawn:/etc/3DxWare/daemon/3dxsrv -d $1 </dev/null >/dev/null 2>&1" >> /etc/inittab
			fi
			DisplayEndInittabInstallation
		else
			if [ "$PORT" = "2" ]
			then
				DisplayStartInittabInstallation
				if [ "$PLATFORM" = "4" ]
				then
				$ECHO "3d:2345:respawn:/etc/3DxWare/daemon/3dxsrv -d $2 </dev/null >/dev/null 2>&1" >> /etc/inittab
				else
				$ECHO "3d:234:respawn:/etc/3DxWare/daemon/3dxsrv -d $2 </dev/null >/dev/null 2>&1" >> /etc/inittab
				fi
				DisplayEndInittabInstallation
			else
				if [ "$PORT" = "3" ]
				then
					DEVICE=3
				else
					$ECHO ""
					$ECHO "Invalid response."
					PORT=0
				fi
			fi
		fi
	done
}

# ************************************************************************
# *      InstallToInittab
# ************************************************************************
InstallToInittab ()
{
	until [ "$DEVICE" = "3" ]
	do
		$ECHO ""
		$ECHO "Do you have a serial device or a USB device?"
		$ECHO ""
		$ECHO " 1. USB device"
		$ECHO " 2. serial device"
		$ECHO " 3. Exit installation"
		$ECHO ""
  	$ECHO "Please enter your choice (1 - 3): [1]"
		$ECHO ""
		read DEVICE
		$ECHO ""
		if [ -z "$DEVICE" ]
		then
			DEVICE=1
		fi

		$ECHO ""
		if [ "$DEVICE" = "1" ]
		then
			DisplayStartInittabInstallation
			if [ "$PLATFORM" = "4" ]
			then
				$ECHO "3d:2345:respawn:/etc/3DxWare/daemon/3dxsrv -d usb </dev/null >/dev/null 2>&1" >> /etc/inittab
			else
				$ECHO "3d:234:respawn:/etc/3DxWare/daemon/3dxsrv -d usb </dev/null >/dev/null 2>&1" >> /etc/inittab
			fi
			DisplayEndInittabInstallation
		else
			if [ "$DEVICE" = "2" ]
			then
				case $PLATFORM in
					1)
						InstallSerialToInittab "/dev/tty0p0" "/dev/tty1p0"
						;;
					2)
						InstallSerialToInittab "/dev/term/a" "/dev/term/b"
						;;
					3)
						InstallSerialToInittab "/dev/tty0" "/dev/tty1"
						;;
					4)
						InstallSerialToInittab "/dev/ttyS0" "/dev/ttyS1"
						;;
				esac
			else
				if [ "$DEVICE" = "3" ]
				then
					PORT=3
				else
					$ECHO "Invalid response."
					$ECHO ""
					DEVICE=0
				fi
			fi
		fi
	done
}


#*************************************************************************
# Main Body
#*************************************************************************

# cd to script directory
cd `$ECHO $0 | sed -e 's/install-3dxunix.sh//g'`

# check to see if installing user is root
id | grep "uid=[0-9](" >/dev/null
if [ $? -ne 0 ] ; then
  CLEAR
	$ECHO "Please login as root and start the installation again!!"
	FatalError
fi

# check to see if the user is installing on this machine
CLEAR
DONE=0
while [ "$DONE" -eq 0 ] ; do
  $ECHO "This installs 3DxWareUnix V1.5.2 on this machine. Continue? (y/n) [y]"
  read ANSWER
	$ECHO ""
  case "$ANSWER" in
    y | Y | "")
      DONE=1
      ;;
    n | N)
      NormalError
      ;;
    q | Q)
      NormalError
      ;;
    *)
      $ECHO "Invalid Response."
      ;;
  esac
done

if [ `$UNAME` = "HP-UX" ]
then
  DEFAULT_CHOICE=1
fi

if [ `$UNAME` = "AIX" ]
then
  DEFAULT_CHOICE=3
fi
if [ `$UNAME` = "SunOS" ]
then
  DEFAULT_CHOICE=2
fi
if [ `$UNAME` = "Linux" ]
then
  DEFAULT_CHOICE=4
fi

until [ "$CHOICE" = "5" ]
do
  DisplayMenu
  read CHOICE
	$ECHO ""
  if [ -z "$CHOICE" ]
  then
    CHOICE=$DEFAULT_CHOICE
  fi

	PLATFORM=0
	$ECHO ""
	case $CHOICE in
		1)
			Install3DxWare "hpux"
			PLATFORM=1
			CHOICE=5
			;;
		2)
			Install3DxWare "solaris"
			PLATFORM=2
			CHOICE=5
			;;
		3)
			Install3DxWare "aix"
			PLATFORM=3
			CHOICE=5
			;;
		4)
			Install3DxWare "linux"
			PLATFORM=4
			CHOICE=5
			;;
		5)
      NormalError
			;;
		*)
			$ECHO "Invalid Response."
			;;
  esac
done

$ECHO ""
DONE=0
while [ "$DONE" -eq 0 ] ; do
	$ECHO "Do you want 3DxWareUnix being started with every login (from the /etc/inittab)? (y/n) [y]"
	read INITTABOPTION
	$ECHO ""
	case "$INITTABOPTION" in
		y | Y | "")
			InstallToInittab
			DONE=1
			;;
		n | N )
			$ECHO "Please start the driver manually. [/etc/3DxWare/daemon/3dxsrv -d <port>]"
			$ECHO ""
			DONE=1
			;;
		*)
			$ECHO "Invalid Response."
			;;
	esac
done

DisplayUsage

exit 0




